These are where the records of episode lists for your DVDs are kept.

Do **NOT** under any circumstance edit these files! They are encrypted in .pkl format, and will break if edited.

Thank you for your understanding.